branch = 'master'
nightly = False
official = True
version = '8.3.0.24082114'
version_name = 'Second Star to the Right'
